KDE Oxygen theme icons
----------------------

The icons in this directory are a subset of the [KDE Oxygen theme icons][1].
See the COPYING file for a copy of the LGPL and some notes about how the
license applies to these icons.

The SVG source format of these icons is available from the [KDE GitHub Mirror][2].

KDE Homepage: [http://www.kde.org/][3]

[1]: https://github.com/KDE/oxygen-icons
[2]: https://github.com/KDE/oxygen-icons/tree/master/scalable
[3]: http://www.kde.org/
